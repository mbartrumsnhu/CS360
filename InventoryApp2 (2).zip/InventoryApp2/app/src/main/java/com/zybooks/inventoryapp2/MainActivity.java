package com.zybooks.inventoryapp2;

import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private LinearLayout itemContainer;
    private InventoryBase dbHelper;
    private ArrayList<InventoryItem> inventoryItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        itemContainer = findViewById(R.id.itemContainer);
        Button addButton = findViewById(R.id.addButton);

        dbHelper = new InventoryBase(this);
        inventoryItems = new ArrayList<>();

        loadItemsFromDatabase();

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InventoryItem newItem = new InventoryItem("", 0);
                long id = dbHelper.addItem(newItem.getName(), newItem.getQuantity());
                newItem.setId(id);
                inventoryItems.add(newItem);
                addItemView(newItem);
            }
        });
    }

    private void loadItemsFromDatabase() {
        Cursor cursor = dbHelper.getAllItems();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int idIndex = cursor.getColumnIndex(InventoryBase.COLUMN_ID);
                int nameIndex = cursor.getColumnIndex(InventoryBase.COLUMN_NAME);
                int quantityIndex = cursor.getColumnIndex(InventoryBase.COLUMN_QUANTITY);

                if (idIndex != -1 && nameIndex != -1 && quantityIndex != -1) {
                    long id = cursor.getLong(idIndex);
                    String name = cursor.getString(nameIndex);
                    int quantity = cursor.getInt(quantityIndex);
                    InventoryItem item = new InventoryItem(id, name, quantity);
                    inventoryItems.add(item);
                    addItemView(item);
                }
            } while (cursor.moveToNext());
            cursor.close();
        }
    }

    private void addItemView(final InventoryItem item) {
        LayoutInflater inflater = LayoutInflater.from(this);
        View newItemView = inflater.inflate(R.layout.item_layout, itemContainer, false);

        EditText dataLabel = newItemView.findViewById(R.id.dataLabel);
        EditText amountEditText = newItemView.findViewById(R.id.amountEditText);
        Button plusButton = newItemView.findViewById(R.id.plusButton);
        Button minusButton = newItemView.findViewById(R.id.minusButton);
        Button deleteButton = newItemView.findViewById(R.id.deleteButton);

        dataLabel.setText(item.getName());
        amountEditText.setText(String.valueOf(item.getQuantity()));

        dataLabel.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                item.setName(s.toString());
                dbHelper.updateItem(item.getId(), item.getName(), item.getQuantity());
            }
        });

        amountEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                String text = s.toString();
                if (!text.isEmpty()) {
                    item.setQuantity(Integer.parseInt(text));
                    dbHelper.updateItem(item.getId(), item.getName(), item.getQuantity());
                }
            }
        });

        plusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                item.increaseQuantity();
                amountEditText.setText(String.valueOf(item.getQuantity()));
                dbHelper.updateItem(item.getId(), item.getName(), item.getQuantity());
            }
        });

        minusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                item.decreaseQuantity();
                amountEditText.setText(String.valueOf(item.getQuantity()));
                dbHelper.updateItem(item.getId(), item.getName(), item.getQuantity());
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbHelper.deleteItem(item.getId());
                itemContainer.removeView(newItemView);
                inventoryItems.remove(item);
            }
        });

        itemContainer.addView(newItemView);
    }

    private static class InventoryItem implements java.io.Serializable {
        private long id;
        private String name;
        private int quantity;

        public InventoryItem(long id, String name, int quantity) {
            this.id = id;
            this.name = name;
            this.quantity = quantity;
        }

        public InventoryItem(String name, int quantity) {
            this.name = name;
            this.quantity = quantity;
        }

        public long getId() {
            return id;
        }

        public void setId(long id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getQuantity() {
            return quantity;
        }

        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }

        public void increaseQuantity() {
            this.quantity++;
        }

        public void decreaseQuantity() {
            if (this.quantity > 0) {
                this.quantity--;
            }
        }
    }
}
